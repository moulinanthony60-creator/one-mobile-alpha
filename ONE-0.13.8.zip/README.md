# ONE Mobile Alpha 0.13.8 — Studio multiplateforme

Base : ZIP local ONE 0.13.7 correspondant à la rotation validée.

## Déploiement
Extraire le ZIP et copier son contenu à la racine du site existant, en conservant icons. Aucune compilation. Le worker de profil reste inchangé ; les services existants restent nécessaires.

## Architecture
- Navigation : Feed | Créer | ONE IA | Abonnements | Réglages.
- Catégories : Pour toi | ONE | TikTok | YouTube | Twitch | Musique | Ciné.
- ONE : salon vide réservé aux futures publications natives, sans faux contenu ni utilisateur.
- Créer : vidéo courte/photo/texte/live, aperçu local des fichiers, titre/description et destinations envisagées ONE/TikTok/YouTube/Twitch.
- Toutes les destinations sont non activées. Aucun envoi, accès caméra ou démarrage de live. Compatibilité des formats et autorisations à intégrer plateforme par plateforme.
- Préparation en mémoire jusqu’au rechargement ou à la fermeture ; fichiers locaux, sans synchronisation.
- Rotation et mélange Pour toi, moteur TikTok, classement Twitch, abonnements et fiches conservés. Fullscreen natif dans les fiches YouTube/Twitch.

Version, manifests et cache actualisés. Clés de connexion/sync/historique conservées. Voir VALIDATION.md.
